import Link from "next/link";
const cases=[
["ml-task-framing","ML Task Framing","Machine Learning","A structured approach to defining a useful ML problem before modeling."],
["prompt-engineering","Prompt Engineering Ladder","AI / Prompt Engineering","A six-stage progression from a weak prompt to a context-rich, audience-aware template."],
["baseline-ranking","Baseline Action Scoring","Applied ML","A transparent baseline that checks signals before scoring and reviews its own top picks."]
];
export default function Work(){return <main><header><Link href="/" className="brand">DF</Link><nav><Link href="/work">Work</Link><Link href="/about">About</Link><Link href="/contact">Contact</Link></nav></header><section className="pagehead"><p className="eyebrow">Work</p><h1>Selected cases</h1><p>Projects from my AI/ML learning and applied systems work.</p></section><section className="grid">{cases.map(([slug,title,type,text])=><Link className="card" href={"/work/"+slug} key={slug}><span>{type}</span><h2>{title}</h2><p>{text}</p><b>Open case →</b></Link>)}</section><footer>© 2026 Danish Faraz</footer></main>}