import "./globals.css";

export const metadata = {
  title: "Danish Faraz — AI Scholar",
  description: "Portfolio of Danish Faraz, an AI scholar and machine learning practitioner."
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}