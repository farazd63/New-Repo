import Link from "next/link";

const cases = [
  {slug:"ml-task-framing", title:"ML Task Framing", type:"Machine Learning", text:"Turning an ambiguous problem into a measurable ML task with a target, metric, action, and data contract."},
  {slug:"prompt-engineering", title:"Prompt Engineering Ladder", type:"AI / Prompt Engineering", text:"Iterating from a weak prompt to a context-rich, audience-aware prompt and documenting the performance changes."},
  {slug:"baseline-ranking", title:"Baseline Action Scoring", type:"Applied ML", text:"Building a transparent rule-based ranking baseline with signal checks, reason codes, actions, and skeptical review."}
];

export default function Home(){
 return <main>
  <header><Link href="/" className="brand">DF</Link><nav><Link href="/work">Work</Link><Link href="/about">About</Link><Link href="/contact">Contact</Link></nav></header>
  <section className="hero">
   <p className="eyebrow">AI Scholar · Machine Learning</p>
   <h1>I build practical AI systems and explain how they work.</h1>
   <p className="lead">Danish Faraz — focused on machine learning, computer vision, prompt engineering, and turning technical ideas into usable systems.</p>
   <div className="actions"><Link className="button" href="/work">View my work</Link><Link className="textlink" href="/about">About me →</Link></div>
  </section>
  <section className="intro"><p className="eyebrow">Selected work</p><h2>Proof over promises.</h2><p>I document the problem, the method, the evidence, and the trade-offs behind each project.</p></section>
  <section className="grid">{cases.map(c=><Link className="card" href={"/work/"+c.slug} key={c.slug}><span>{c.type}</span><h3>{c.title}</h3><p>{c.text}</p><b>Read case →</b></Link>)}</section>
  <footer>© 2026 Danish Faraz</footer>
 </main>
}