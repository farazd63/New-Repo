# Danish Faraz Portfolio — Build Week

Stack: Next.js 14 + React 18 + Vercel.

Pages:
- /
- /work
- /work/ml-task-framing
- /work/prompt-engineering
- /work/baseline-ranking
- /about
- /contact

Run:
npm install
npm run dev

Deploy:
Push to GitHub and import the repository into Vercel.

Before final submission:
1. Replace/add actual project screenshots and repository/demo links.
2. Add the real LinkedIn/GitHub URLs.
3. Open every page on desktop and phone.
4. Send the live URL to one real person and record their reaction.
5. Complete the still-ugly list.
