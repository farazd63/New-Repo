# FL-07 — Research Scout Agent MVP

Platform: Claude Project + one read-only local knowledge source.

## Core job
Turn one AI/ML research question into a concise, source-grounded research brief.

## Live connection used
A local/project knowledge source containing research notes and references. In Claude, upload the files to the Project Knowledge area and use them as the real data connection.

## Claude Project instructions
Copy `agent_instructions.txt` into the Project instructions.

## MVP run
Use a brand-new question:
"Compare Logistic Regression and Random Forest for binary classification. Explain when each is preferable and cite the evidence available in the project knowledge."

The successful run must show:
1. User question
2. Agent searches/reads the connected project knowledge
3. Agent synthesizes evidence
4. Agent returns the structured research brief

## Evidence
Record an unedited ~2 minute screen capture of the successful run in Claude. Do not claim a recording exists until you actually record it.

See BUILD_LOG.md for the iteration log.
