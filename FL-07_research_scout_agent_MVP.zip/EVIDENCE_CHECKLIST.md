# FL-07 Submission Evidence Checklist

- [ ] Working Claude Project exists.
- [ ] Research Scout instructions are installed.
- [ ] At least one real connected data source is enabled.
- [ ] Brand-new research question completes end to end.
- [ ] No mid-run hand editing.
- [ ] Build log records actual iterations.
- [ ] Deviations from FL-06 are documented.
- [ ] Raw ~2 minute screen capture recorded.
- [ ] Screenshot/evidence of the live connection captured.
- [ ] Final run output captured.
