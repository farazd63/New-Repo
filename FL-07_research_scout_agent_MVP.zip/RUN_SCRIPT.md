# FL-07 Run Capture Script

Use this as the exact sequence for the raw screen recording.

1. Open the Claude Project.
2. Keep the Project instructions and connected knowledge visible/available.
3. Start recording.
4. Enter exactly:

Compare Logistic Regression and Random Forest for binary classification. Explain when each is preferable and cite the evidence available in the project knowledge.

5. Do not manually edit the answer while the agent is running.
6. Let the agent complete the full research loop.
7. Show the final structured brief and source evidence.
8. Stop recording.

The recording should be approximately 2 minutes and unedited.
