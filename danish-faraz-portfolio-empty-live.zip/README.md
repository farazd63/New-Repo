# Danish Faraz Portfolio

Near-blank portfolio foundation for the Empty-but-Live milestone.

## Deploy with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` and `.nojekyll`.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`.
5. Open the generated URL on your phone.

The portfolio content will be added during the next build week.
